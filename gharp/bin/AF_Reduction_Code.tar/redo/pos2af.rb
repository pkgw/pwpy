#! /usr/bin/env ruby

require 'matrix'
require 'mathn'
include Math

###############################################################
#
#  ascii2spadats.rb
#  
#  Converts ascii files of observation data into the USAF SPADATS
#  file format.  Is coded only for "type 1" observations of
#  elevation and azimuth, since this is the data format currently
#  produced by the ATA.  This script can be modified for additional
#  observation types if those are appropriate in the future.
#  SOURCE DATA: "B-3 ob formats.doc" Provided to SETI by USAF sp2009
#
#  Author: William C. Barott
#  Original Date: June 1 2009
#  Last Revised Date: 
#
################################################################

if ARGV[0] == nil
    # If no arguments have been passed, return the usage
    puts ""
    puts "SYNOPSIS"
    puts "\tascii2spadats.rb satnum infile outfile [year month day]"
    puts "DESCRIPTION"
    puts "\tTranslates ascii observations to the USAF SPADATS format"
    puts "\tAt present, only the type-1 observations are supported."
    puts "\tArguments are:"
    puts "\tSATNUM: The NORAD satellite number of the source.  This is identifed"
    puts "\t\t from the TLE or from other sources."
    puts "\tINFILE: The input ascii file containing data in the proper format"
    puts "\tOUTFILE: The output ascii file to use for the observation"
    puts "\t[year month day]: Optionally used if the input file has times in UT"
    puts "\t  seconds from start of day. (Gerry's results format)"
    puts "EXAMPLES"
    puts "\tascii2spadats.rb 1234 obs.txt sat.track"
    puts "\tTranslates ascii data in \"obs.txt\" to the SPADATS format and writes"
    puts "\tthe translated data to \"sat.track\" for satellite tag #1234"
    puts "\tascii2spadats.rb 1234 obs.txt sat.track 2009 05 19"
    puts "\t Expects time to be in UT seconds from start of day."
    exit
end

def is_a_number?(s)   
    s.to_s.match(/\A[+-]?\d+?(\.\d+)?\Z/) == nil ? false : true  
end

#==========================================================================#
# Function delcarations for conversion process                             #
#==========================================================================#

def padz(str, len)
    # Pad zeros on to the left side of the string to meet the length
    str = str.to_s
    if str.length > len
        raise "Error in padz: String length is #{str.length}, desired length is #{len}"
    end
    strout = "#{"0"*(len-str.length)}#{str}" 	# Pad to length
    return strout
end
def blank(len)
    # Create a blank string with the given length
    return " "*len
end
def spadatsHeader(satnum = 0, msgnum=0, reportind=0, stationnum = 0, obstype = 0, classification="U")
    # Create the header information common to all data types
    # Variables are named according to description and USAF field number
    # If a nil-value is passed, it will be blanked in the returned string
    # If an incorrect value is passed, an error will be raised.
    som_3 = "))"	# Start of message, two characters
    
    # Target classification, must be unclassified, classified, or secret
    class_4 = classification.upcase
    if (class_4 != "U")&&(class_4 != "C")&&(class_4 != "S")
        raise("Target classification is #{class_4}, must be one of U,S,C")
    end
    
    # Message number.  Must be between 0 and 999, and be three characters
    if msgnum == nil
        msgnum_5 = blank(3)
    else
        msgnum_5 = msgnum.to_s
        if (msgnum > 999)||(msgnum < 0)
            raise("Message number is #{msgnum}, must be between 0 and 999")
        end
        msgnum_5 = padz(msgnum_5, 3) 	# Pad to length
    end
    
    # Report indicator, must be 1..9 as in document, single character
    if reportind == nil
        reportind_6 = blank(1)
    else
        reportind_6 = reportind.to_s
        if (reportind < 1)||(reportind > 9)
            raise("Report Indicator is #{reportind}, must be between 1 and 9")
        end
    end
    
    # Observation type, must be 0..9 as in document, single character
    if obstype == nil
        obstype_7 = blank(1)
    else
        obstype_7 = obstype.to_s
        if (obstype < 0)||(obstype > 9)
            raise("Observation type is #{obstype}, must be between 0 and 9")
        end
    end
    
    # Station number, must be three characters between 001 and 999
    if stationnum == nil
        stationnum_8 = blank(3)
    else
        stationnum_8 = stationnum.to_s
        if (stationnum < 1) || (stationnum > 999)
            raise("Station number is #{stationnum}, must be between 001 and 999")
        end
        stationnum_8 = padz(stationnum_8, 3)
    end
    
    # Satellite number (from TLE ID), must be 5 characters
    if satnum == nil
        satnum = blank(5)
    else
        satnum_9 = satnum.to_s
        if (satnum < 1) || (satnum > 99999)
            raise("Satellite number is #{satnum}, must be between 00001 and 99999")
        end
        satnum_9 = padz(satnum_9, 5)
    end
    
    hdr = ""
    hdr << som_3
    hdr << class_4
    hdr << msgnum_5
    hdr << reportind_6
    hdr << obstype_7
    hdr << stationnum_8
    hdr << satnum_9
    return hdr
end
def spadatsBodyType1(time, el, az, taiflag=nil, elwt=nil, azwt=nil)
    # Create the body (post-header) observation string for the type-1
    # SPADATS observation.  Uses same variable name rules as the header.
    time_10 = numericTime2spadatsTime(time, taiflag)	# String time
    el_11 = numericEl2spadatsEl(el)
    if elwt == nil
        elwt_12 = blank(1)
    else
        elwt_12 = elwt.to_s
        if (elwt < 0) || (elwt > 7)
            raise("Elevation weight is #{elwt}, must be between 0 and 7")
        end
        elwt_12 = padz(elwt_12,1)
    end
    
    az_13 = numericAz2spadatsAz(az)
    if azwt == nil
        azwt_14 = blank(1)
    else
        azwt_14 = azwt.to_s
        if (azwt < 0)||(azwt > 7)
            raise("Azimuth weight is #{azwt}, must be between 0 and 7")
        end
        azwt_14 = padz(azwt_14,1)
    end
    
    checksum_15 = blank(1)	# Checksum is not calculated
    eobs_16 = "$$"	# End of observation
    cr = 13.chr
    lf = 10.chr
    eline_17 = "#{cr}#{cr}#{lf}"
    body = ""
    body << time_10
    body << el_11
    body << elwt_12
    body << az_13
    body << azwt_14
    body << checksum_15
    body << eobs_16
    body << eline_17
    return body    
end
def numericAz2spadatsAz(az)
    # Convert the numeric value of azimuth (in degrees) into the SPADATS
    # seven-character format for azimuth, return as a string
    az = clampAz(az)
    if az < 0
        raise("Azimuth passed is #{az}, but azimuth must be positive")
    end
    if az > 360
        raise("Azimuth passed is #{az}, but azimuth must be less than 360 degrees")
    end
    bigaz = (az*10000).round
    stringaz = padz(bigaz,7)
    return stringaz
end
def clampAz(az)
    # Bound an input azimuth (in degrees) to be between 0 and 360.
    if az < 0
        return clampAz(az+360)
    elsif az > 360
        return clampAz(az-360)
    else
        return az
    end
end
def numericEl2spadatsEl(el)
    # Convert a numeric value of elevation (in degrees) into the SPADATS
    # seven-character format for elevation, return as a string
    if el < 0
        elflag = "1"
    else
        elflag = "0"
    end

    absel = el.abs
    if absel > 90
        raise("Elevation passed is #{el}, but magnitude must be less than 90 degrees")
    end
    bigel = (absel*10000).round
    stringbigel = padz(bigel,6)
    stringel = "#{elflag}#{stringbigel}"
    return stringel
end
def numericTime2spadatsTime(intime, taiflag=nil)
    # Convert a numeric time to the SPADATS time format.
    # input time should be seconds since the epoch.  If the last argument
    # is omitted (or anything but 'tai') then time should be in UTC.
    # setting the second argument to 'tai' will modify by the TAI adjustment

    atomic_offset = 34		# As of 1/1/2009
    if taiflag != nil
        if taiflag.upcase == "TAI"
            intime = intime + atomic_offset
        end
    end
    
    # Now sort through the input time and separate out the parts
    t = Time.at(intime).utc
    year = t.year
    day = t.yday
    hour = t.hour
    minute = t.min
    sec = t.sec
    ms = (t.usec/1000).round
    secms = sec * 1000 + ms
    
    # Turn into a string and return
    stringday = padz(day,3)
    stringhour = padz(hour,2)
    stringminute = padz(minute,2)
    stringsecms = padz(secms,5)
    spadatstime = "#{stringday}#{stringhour}#{stringminute}#{stringsecms}"
    return spadatstime
end

def yRotation(long,lat,theta)
  thetaRad = theta*PI/180
  rotMatrix = Matrix[[cos(thetaRad),0.0,sin(thetaRad)],[0.0,1.0,0.0],[-sin(thetaRad),0.0,cos(thetaRad)]]
  longRad = long*PI/180
  latRad = lat*PI/180
  xpos = Matrix[[cos(latRad)*cos(longRad),cos(latRad)*sin(longRad),sin(latRad)]]
  xPrime = xpos*rotMatrix
  longPrimeRad = atan2(xPrime[0,1],xPrime[0,0])
  latPrimeRad = asin(xPrime[0,2])
  latPrime = latPrimeRad*180/PI
  longPrime = longPrimeRad*180/PI
  return [longPrime,latPrime]
end

def zRotation(long,lat,theta)
  thetaRad = theta*PI/180
  rotMatrix = Matrix[[cos(thetaRad),-sin(thetaRad),0.0],[sin(thetaRad),cos(thetaRad),0.0],[0.0,0.0,1.0]]
  longRad = long*PI/180
  latRad = lat*PI/180
  xpos = Matrix[[cos(latRad)*cos(longRad),cos(latRad)*sin(longRad),sin(latRad)]]
  xPrime = xpos*rotMatrix
  longPrimeRad = atan2(xPrime[0,1],xPrime[0,0])
  latPrimeRad = asin(xPrime[0,2])
  latPrime = latPrimeRad*180/PI
  longPrime = longPrimeRad*180/PI
  return [longPrime,latPrime]
end


#==========================================================================#
# Script process starts now                                                #
#==========================================================================#

satnum = ARGV[0].to_i
fnin = ARGV[1]
fnout = ARGV[2] 

stationnum = 156	# The station number for the ATA.
			# Change when assigned new one by USAF
obstype = 1		# Observation type.  This is the only one for now.
classification="U"	# Unclassified.  For this script, that is all data.
msgnum = 1

# Status messge:
puts "Translating observation data to type #{obstype} for SPADATS"
puts "Input file: #{fnin}"
puts "Output file: #{fnout}"

filein = File.new(fnin,'r')
datain = filein.readlines
filein.close
fileout = File.new(fnout,'w')
puts "Translating #{datain.length} lines..."
datain.each do |cline|

    dataline = cline.scan(/\S+/)	# Scan into the format [time, el, az]
   
    if is_a_number?(dataline[0]) # Do not process lines that do not start with a number
      obstime = dataline[0].to_f   #File UTC. Taken as column "0" to be consistent with ATA
      				   # Time formats should be in DECIMAL SECONDS, UTC.
      obsel =   dataline[2].to_f   #File el.  Taken as column "2" to be consistent with ATA
      obsaz =   dataline[1].to_f   #File az.  Taken as column "1" to be consistent with ATA

      reportind = 2	# Single track point.  This might not be the best way.
      hdr = spadatsHeader(satnum, msgnum, reportind, stationnum, obstype, classification)
      body = spadatsBodyType1(obstime, obsel, obsaz)
      msg = "#{hdr}#{body}"
      fileout.printf(msg)
      msgnum = msgnum + 1	# increment the message number
   end

end

fileout.close
puts "Done, files closed."

