#!/usr/bin/env jruby
require 'java'

#this forces writes to files to happen immediately.
$stdout.sync = true

require 'fileutils.rb'
require 'net/smtp'
import 'ata.ataTime.ATATime'


def self.starts_with?(line, str)
      str = str.to_str
      head = line[0, str.length]
      head == str
end

#######################################################
# Small class used as a container for the information
# needed when running newrfisweep and newcalcal.
# Historically this was done with a script called
# "reduce".
#######################################################
class ReduceInfo
  attr_accessor :cal, :freq, :flux, :startChannel, :endChannel

  def initialize(cal, freq, flux, startChannel, endChannel)
    @cal = cal
    @freq = freq
    @flux = flux
    @startChannel = startChannel;
    @endChannel = endChannel;
  end

end

######################################################
# Small class used as a container for satellite info.
######################################################
class ProcessSatInfo
  attr_accessor :cals, :sat, :startChannel, :endChannel, :ephemFilename, :numChannels

  def initialize(cals, sat)
    @sat = sat
    @startChannel = sat.startChannel
    @endChannel = sat.endChannel
    @ephemFilename = sat.objectName + ".ephem";
    @numChannels = @endChannel.to_i - @startChannel.to_i + 1;

    @cals = Array.new#
    cals.each do |cal|
      if(cal.dynamicRange.to_f > 0)
        @cals << cal;
      end
    end
    @cals.sort! { |a, b| b.dynamicRange <=> a.dynamicRange}
  end

end



#######################################################
# Small class used as a container for information about
# cals or sats.
#######################################################
class CalSatInfo

  attr_accessor :norad, :visname, :corr, :objectName, :freqMHz, :startChannel, :endChannel, :dynamicRange, :firstPositionTimeDate, :lastPositionTimeDate, :tempFilename, :status, :outputFilename, :posCount


  def initialize(line, type)

    @posCount = 0;
    if(type.eql?("SAT:"))
      readSat(line);
    end
    if(type.eql?("CAL:"))
      readCal(line);
    end
 
    length=12
    @tempFilename = ""  
    chars = ("A".."Z").to_a  
    length.times do    
      @tempFilename << chars[rand(chars.length-1)]  
    end
  end

  ###################################################
  # Get the norad number of a satellite
  ###################################################
  def getNorad(satName)

    puts "atagettle #{satName}";
    cmd = `atagettle #{satName}`;

    cmd.each do |line|
      if starts_with?(line, "2")
        line = line.chomp
        line = line.rstrip
        norad = line[2..6]
        return norad
      end
    end

    return "0";

  end

  def readCal(line)
    @norad = "0";
    @visname = "none";
    @corr = "x";
    @objectName = "none";
    @freqMHz = "-1";
    @startChannel = "-1";
    @endChannel = "-1";
    @dynamicRange = "-1";
    @firstPositionTimeDate = "0";
    @lastPositionTimeDate = "0";
    @status = "";
    @outputFilename = "0";

    partsArray = line.strip().split(",")
    if(partsArray.length > 0)
      @visname = partsArray[0];
      if(partsArray.length > 1)
        @corr = partsArray[1];
        if(partsArray.length > 2)
          @objectName = partsArray[2];
          if(partsArray.length > 3)
            @freqMHz = partsArray[3];
            if(partsArray.length > 4)
              @startChannel = partsArray[4];
              if(partsArray.length > 5)
                @endChannel = partsArray[5];
              end
            end
          end
        end
      end
    end
  end

  # Read the sat or cal information from a text string
  # The format for a cal is: 
  #   directory,calibrator,source name,freg MHz
  # The format for a sat is:
  #   directory,calibrator,source name,freg MHz,start channel, end channel
  def readSat(line)
    @norad = "0";
    @visname = "none";
    @corr = "x";
    @objectName = "none";
    @freqMHz = "-1";
    @startChannel = "-1";
    @endChannel = "-1";
    @dynamicRange = "-1";
    @firstPositionTimeDate = "0";
    @lastPositionTimeDate = "0";
    @status = "";
    @outputFilename = "0";

    partsArray = line.strip().split(",")
    if(partsArray.length > 0)
      @visname = partsArray[0];
      if(partsArray.length > 1)
        @corr = partsArray[1];
        if(partsArray.length > 2)
          @objectName = partsArray[2];
          if(partsArray.length > 3)
            @freqMHz = partsArray[3];
            if(partsArray.length > 4)
              @startChannel = partsArray[4];
              if(partsArray.length > 5)
                @endChannel = partsArray[5];
              end
            end
          end
        end
      end
    end

    if($processingFreqMHz.eql?(@freqMHz))
      @norad = getNorad(@objectName);
      if(@norad.eql?("0"))
        puts "Fatal Error: Can not find NORAD number for #{@objectName}\n";
        puts "You must find the correct name for this satellite and make\n";
        puts "sure it gets a TLE using \"atagettle\".\nEXITING\n";
        exit;
      end
    end

  end

  # Convenience method to print out the data as a string that would be in
  # a callist of satlist file
  def toString()
    return @visname + "," + @corr + "," + @objectName + "," + @freqMHz + "," + @startChannel + "," + @endChannel + "," + @dynamicRange.to_s + "," + @norad;
  end

  def starts_with?(line, str)
      str = str.to_str
      head = line[0, str.length]
      head == str
  end

  def reportError(str)
    if(@status.length == 0)
      @status = str;
    end
  end

  # Convenience method to print out the data as a string that would be in
  # a callist of satlist file, but with field labels.
  def toInfoString()
    return "vis:" + @visname + ",Corr:" + @corr + ",Name:" + @objectName + ",FreqMHz:" + @freqMHz + ",Start:" + @startChannel + ",End:" + @endChannel;
  end
  
  # Get the name of the temporary output position file.
  def getTempOutputFileName()
    return @tempFilename;
  end

  # Get the real output position file name. This name depends on the 
  # times read from the temporary output file.
  def getOutputFileName()
 
    if(@outputFilename.eql?("0") == false)
      return @outputFilename;
    end

    # From the temp output position file get the first and last position times. 
    first = "0";
    last = "0";

    if(File.exists?($homeDir + "/" + getTempOutputFileName().to_s + ".pos") == false)
      return "xxxx.xxxx";
    end

    posFile = File.open($homeDir + "/" + getTempOutputFileName().to_s + ".pos", "r")
    while (line = posFile.gets)
      line = line.strip
      line = line.rstrip

      if(starts_with?(line, "#") == false)

        parts = line.chomp.split(" ");
        if(first.eql?("0") )
          if(starts_with?(parts[0], "12"))
            @posCount = @posCount+1;
            first = parts[0];
          end
        else 
          if (starts_with?(parts[0], "12") )
            @posCount = @posCount+1;
            last = parts[0];
          end
        end
      end

    end
    posFile.close();


    # Conver to ISO 8601 UTC
    # YYYY-MM-DDTHH:MM:SS.999999999Z
    @firstPositionTimeDate = Java::ata::ataTime::ATATime.formatUTC(first.to_i*1000000000);
    @lastPositionTimeDate = Java::ata::ataTime::ATATime.formatUTC(last.to_i*1000000000);

    # Get the date time parts
    year   = @firstPositionTimeDate[0..3];
    month  = @firstPositionTimeDate[5..6];
    day    = @firstPositionTimeDate[8..9];
    hour   = @firstPositionTimeDate[11..12];
    minute = @firstPositionTimeDate[14..15];
    second = @firstPositionTimeDate[17..-2];

    # Create the name like 20090421-001035-21639-TDRS-5
    secInt = second.to_i.to_s
    name =  year + month + day + "-" + hour + minute + secInt + "-" + @norad + "-" + @objectName + "-" + @freqMHz;

    @outputFilename = name;

    if(File.exists?(name + ".pos"))
      File.delete(name + ".pos");
    end
    if(File.exists?(name + ".txt"))
      File.delete(name + ".txt");
    end
    if(File.exists?(name + ".obs"))
      File.delete(name + ".obs");
    end

    return name;

  end
   
end

#################################################
# Convert a UTC date time to a date time string.
#################################################

def self.UTC2DateTimeString(utc)

    t = Java::ata::ataTime::ATATime.formatUTC(utc.to_i*1000000000);

    # Get the date time parts
    year   = t[0..3];
    month  = t[5..6];
    day    = t[8..9];
    hour   = t[11..12];
    minute = t[14..15];
    second = t[17..-2];

    dateString = year + "/" + month + "/" + day + "-" + hour + ":" + minute + ":" + second;

    return dateString;

end

####################################################
# Read an array from a \n delimited file
###################################################
def self.readArrayFromFile(type, filepath = nil, freqMHz = 0.0)

  if filepath == nil
    puts "Usage: readArrayFromFile(filename)"
    exit
  end

  arrayFile = File.open(filepath, "r")
  returnArray = Array.new#
  while (line = arrayFile.gets)
    line = line.strip
    line = line.rstrip
    if starts_with?(line, type) == true
      ca = CalSatInfo.new(line[4..-1], type);
      if(ca.freqMHz.to_f == freqMHz)
        returnArray << ca;
      end
    end
  end
  arrayFile.close();

  return returnArray
end

############################################################
# Create a string of cals or sats from a list, \n delimited.
############################################################
def calSatArrayToString(header, calSatArray)
  outString = header + "\n";

  calSatArray.each do |calSat|
    outString += calSat.toString() + "\n";
  end
 
  return outString;

end

############################################################
# Create a string that contains the input parameters if all
# cal or sats.
############################################################
def calSatArrayToInfoString(header, calSatArray)
  outString = header + "\n";

  calSatArray.each do |calSat|
    outString += calSat.toInfoString() + "\n";
  end

  return outString;

end


###################################################
# Log the list of cals or sats to the log file.
###################################################
def self.logList(header, objects)

  listAsString = calSatArrayToString(header, objects);  
  executeAndLog(listAsString, false);

end


###################################################
# Get the flux for an object by caling calinfo
###################################################
def self.getFlux(calShortName, freqMHz)
  # Need to call "calinfo target=3c119 freq=1.628"
  # object should be in the form of mosfxa-3c286-1628, so split to get name

  freq = freqMHz.to_f/1000.0;
  executeAndLog("calinfo target=" + calShortName + " freq=" + freq.to_s, false);

  commandOutput = IO.popen("calinfo target=" + calShortName + " freq=" + freq.to_s)
  while(line = commandOutput.gets)
    parts = line.chomp.split(" ");
    if parts[0].eql?("Estimated") 
      return parts[2]
    end 
  end

  return "0.0"

end

###################################################
# Convenience function. Test to see if an object is
# in a list.
# Not used anymore. At first I had a "noreduce" file
# that listed the cals not to reduce. But not I just
# expect to have the operator comment the ones out of
# the "callist" file by placing a hash character in
# front of the line. I am leaving this in the code just
# in case I want to do this in the future. - JR
###################################################
def self.isInList(calOrSatinfo, objectList)

  objectList.each do |obj|
    if obj.visname.eql?(calOrSatinfo.visname)
      if obj.freqMHz.eql?(calOrSatinfo.freqMHz)
        return true
      end
    end
  end

  return false

end

###################################################
# Run reduce, which is newrfisweep.csh and newcalcal.csh
###################################################
def self.runReduce(cals)

  executeAndLog(">>Start All cals reducing", false);
  th = Array.new#
  cals.each do |calInfo|

    executeAndLog("sleep 5", true);
    flux = getFlux(calInfo.objectName, calInfo.freqMHz);

    # If the flux is 0.0, it is invalid and do not run reduce.
    if(flux.eql?("0.0") == false)
      ri = ReduceInfo.new(calInfo.visname, calInfo.freqMHz, flux, calInfo.startChannel, calInfo.endChannel);
      th << Thread.new(ri) {|myri| sc = myri.startChannel.to_i + 1; ec = 1025 - myri.endChannel.to_i;   executeAndLog("Reducing for cal:" + myri.cal + ", freq:" + myri.freq + ", flux:" + myri.flux.to_s, false);  executeAndLog(">>Start newrfisweep " + myri.cal, false); executeAndLog("unflagging " + myri.cal, false); puts "\n***\nRUNNING: uvflag vis=" + myri.cal + " options=none flagval=u"; executeAndLog("uvflag vis=" + myri.cal + " options=none flagval=u", true); executeAndLog("uvflag vis=" + myri.cal + " options=none flagval=flag line=chan," + sc.to_s + ",1", true); executeAndLog("uvflag vis=" + myri.cal + " options=none flagval=flag line=chan," + ec.to_s + "," + myri.endChannel.to_s, true); executeAndLog("uvflag vis=" + myri.cal + " flagval=flag select=\"ant(26,28),pol(xx)\"", true); puts "\n***\nFINISHED: uvflag vis=" + myri.cal + " options=none flagval=u";  executeAndLog("newrfisweep.csh vis=" + myri.cal + " options=autoedge,rescan subint=999 scans=4 corrcycle=0", true); executeAndLog("<<Finish newrfisweep " + myri.cal, false); executeAndLog(">>Start newcalcal " + myri.cal , false); executeAndLog("newcalcal.csh vis=" + myri.cal + " flux=" + myri.flux + " plim=15 options=polsplit,outsource,sefd,wrath,autocal", true); executeAndLog("<<Finish newcalcal " + myri.cal , false); }
    end

  end

  th.each do |t|
    t.join;
  end

  executeAndLog("<<Finish All cals reducing", false);

end

###################################################################################
# Run newcalcal with the best calibrator, copying the gains to the satellites.
###################################################################################
def self.copyGainsFromCalToSat(cal, sat)

  # Use newcalcal to copy the gains
  executeAndLog(">>Start newcalcal copy gains to " + sat , false)
  
  # Here we need to make sure only ONE process is copying the gains. Having
  # multiple gain copies sometimes resulted in the gains copy failing.
  executeAndLog("newcalcal.csh vis=" + cal + " tvis=" + sat + " options=copy", false); ##Log, do not execute.
  Thread.critical = true;
  system("newcalcal.csh vis=" + cal + " tvis=" + sat + " options=copy");
  Thread.critical = false;
  executeAndLog("<<Finish newcalcal copy gains to " + sat , false)

end

######################################################################
# Get data from calrpt. The resulting data is stored in an array.
# See the end of this method for a list and order of the information
# stored in the array. TODO: I really should make a class to store 
# this information - JR.
######################################################################
def self.getDataFromCalrpt(cal)

  filename = $homeDir + "/cal-" + cal.objectName + "-" + cal.freqMHz.to_s + "-maps/calrpt";
  puts "getDataFromCalrpt(), filename = " + filename;
  executeAndLog("getDataFromCalrpt() opening " + filename, false);
puts filename
  #If the calrpt does not exist, erturn null;
  if(File.exists?(filename) == false)
    return nil;
  end

  calrptFile = File.open(filename, "r")
  returnArray = Array.new#

  imageNoise = 0.0;
  dynamicRange = 0.0;
  theoreticalNoiseLimit = 0.0;
  dataRetentionX = 0.0;
  dataRetentionY = 0.0;
  po1 = 0.0;
  po2 = 0.0;
  po3 = 0.0;
  po4 = 0.0;

  while (line = calrptFile.gets)
    line = line.chomp
    line = line.rstrip
    if starts_with?(line, "Image noise is ")
      parts = line.chomp.split(" ");
      imageNoise = parts[3].to_f;
      dynamicRange = parts[10].to_f;
    end
    if starts_with?(line, "(theoretical noise limit is ")
      parts = line.chomp.split(" ");
      theoreticalNoiseLimit = parts[4].to_f;
    end
    if starts_with?(line, "   X-Pol:")
      parts = line.chomp.split(" ");
      dataRetentionX = parts[1].chop.to_f;
    end
    if starts_with?(line, "   Y-Pol:")
      parts = line.chomp.split(" ");
      dataRetentionY = parts[1].chop.to_f;
    end
    if starts_with?(line, "Positional offsets are")
      parts = line.chomp.split(" ");
      parts2 = parts[3].split(",");
      po1 = parts2[0].to_f;
      po2 = parts2[1].to_f;
      parts2 = parts[5].split(",");
      po3 = parts2[0].to_f;
      po4 = parts2[1].to_f;
    end
  end

  returnArray << cal.visname;
  returnArray << imageNoise;
  returnArray << dynamicRange;
  returnArray << theoreticalNoiseLimit;
  returnArray << dataRetentionX;
  returnArray << dataRetentionY;
  returnArray << po1;
  returnArray << po2;
  returnArray << po3;
  returnArray << po4;

  return returnArray;
end

##################################################
# Print out a string with the calrpt information.
##################################################
def self.calrptToString(calrptArray)

  puts "Cal:                #{calrptArray[0]}";
  puts "Image Noise:        #{calrptArray[1]}";
  puts "Dynamic Range:      #{calrptArray[2]}";
  puts "Theo Noise Limit:   #{calrptArray[3]}";
  puts "Data Retention X:   #{calrptArray[4]}";
  puts "Data Retention Y:   #{calrptArray[5]}";
  puts "Positional Offsets: #{calrptArray[6]},#{calrptArray[7]} +/- #{calrptArray[8]},#{calrptArray[9]}";
  
end

###################################################
# Execute and log
###################################################
def executeAndLog(command, executeCommand)

  Thread.critical = true;
  f = File.open($homeDir + "/log_" + $processingFreqMHz + ".txt",  "a")
  time = Time.new
  dateAndCommand = "[" + time.day.to_s + "/" + time.month.to_s + "/" + time.year.to_s + " " + time.hour.to_s + ":" + time.min.to_s + ":" + time.sec.to_s + "] " + command
  f.puts(dateAndCommand)
  f.flush
  f.fsync
  f.close
  Thread.critical = false;

  if(executeCommand == true)
    system(command)
  end

end

#############################
# Determine if the cal is OK
#############################
def self.isCalOK(calrptArray)

  if(calrptArray == nil)
    return false;
  end

  cal = calrptArray[0];
  imageNoise = calrptArray[1];
  dynamicRange = calrptArray[2];
  theoreticalNoiseLimit = calrptArray[3];
  dataRetentionX = calrptArray[4];
  dataRetentionY = calrptArray[5];
  po1 = calrptArray[6];
  po2 = calrptArray[7];
  po3 = calrptArray[8];
  po4 = calrptArray[9];

  if(dataRetentionX <= 30.0)  
    return false;
  end
  if(dataRetentionY <= 30.0) 
    return false;
  end
  if((imageNoise/theoreticalNoiseLimit) > 100.0) 
    return false;
  end

  if(po1 >= (po3*3.0))
    return false;
  end
  if(po2 >= (po4*3.0))
    return false;
  end

  return true;

end

##############################################
# Get the best Cal (best dynamic range)
##############################################
def self.getDynamicRanges(cals)

  cals.each do |cal|
    ar = getDataFromCalrpt(cal);  
    if(isCalOK(ar) == true)
      cal.dynamicRange = ar[2];
    end
  end

end

###################################################
# Process each satellite
###################################################
def self.processSats(cals, sats)

  getDynamicRanges(cals);

  th = Array.new#

  executeAndLog(">>Start Processing Sats", false);

   count = 0;

  sats.each do |sat|
 
    ephemFilename = sat.objectName + ".ephem";

    pi = ProcessSatInfo.new(cals, sat);
    th << Thread.new(pi) {|mypi| processOneSat(mypi); }
    sleep 5; #sleep 5 seconds to avoid opening the same cal file simultaneously

    count = count + 1;

    if(count >= 3)
      runningCount = count;
      while(runningCount >= 3)
        sleep(10);
        #puts "\n*** Thread report: ***";
        runningCount = 0;
        th.each do |t|
          if(t.status.eql?("run"))
            runningCount = runningCount + 1;
          end
          #puts "\t" + t.inspect;
        end
      end
      count = runningCount;
    #  puts "\n";
    #else
    #  puts "\nThread count = " + count.to_s;
    end

  end


  th.each do |t|
    t.join;
  end

  executeAndLog("<<Finish Processing Sats", false);

end

def self.processOneSat(processInfo)

  begin

    finished=false; 
    outputFileName = processInfo.sat.getTempOutputFileName();

    # puts calSatArrayToString("CALS: ", processInfo.cals.toString());
    puts calSatArrayToInfoString("CALS:", processInfo.cals);

    if(File.exists?(processInfo.sat.to_s + ".pos"))
      File.delete(processInfo.sat.to_s + ".pos");
    end

    while(finished == false) 
      executeAndLog(">>Start Processing " +  processInfo.sat.visname, false); 
      executeAndLog("uvflag vis=" + processInfo.sat.visname + " options=none flagval=u", true); 
      copyGainsFromCalToSat(processInfo.cals[0].visname, processInfo.sat.visname); 
      executeAndLog("csh -c 'setenv PATH /hcro/opt/bin:$PATH && astrolabe.rb " + processInfo.sat.visname + " line=chan," + processInfo.numChannels.to_s + "," + processInfo.startChannel.to_s + " " + processInfo.ephemFilename + " " + outputFileName + ".pos " + processInfo.sat.freqMHz.to_s + "'", true); 

      if(File.exists?(outputFileName + ".pos")  && (File.size(outputFileName + ".pos") > 100) )
        finished = true;
        createInfoFile(processInfo.sat, processInfo.cals[0]);
        File.rename(outputFileName + ".pos", processInfo.sat.getOutputFileName() + ".pos");
        #Convert to the air force format.
        executeAndLog("pos2af.rb " + processInfo.sat.norad + " " +   processInfo.sat.getOutputFileName() + ".pos " + processInfo.sat.getOutputFileName() + ".obs" , true);
      else
        if( processInfo.cals.length > 1)
          executeAndLog("astrolabe for " + processInfo.sat.visname + " with cal=" + processInfo.cals[0].visname + " failed, trying next one.", false);
          processInfo.cals.slice!(0);
        else
          finished = true;
          executeAndLog("astrolabe for " + processInfo.sat.visname + " with cal=" + processInfo.cals[0].visname + " failed, no more cals in list.", false);
        end
      end
    end
  rescue
puts "ERROR";
    processInfo.sat.reportError("Error processing satellite.");
  end 

puts processInfo.sat.getOutputFileName() + ".pos";

  if(File.exists?( processInfo.sat.getOutputFileName() + ".pos"))
    processInfo.sat.reportError("Successful.");
  else
    processInfo.sat.reportError("Error, position file not created..");
  end 

  executeAndLog("<<Finish Processing " +  processInfo.sat.visname, false); 

end

###################################################
# Create information file for one satellite
# Example info file:
#   Satellite: TDRS-5
#   NORAD Number: 21639
#   Date: April 21, 2009
#   Start Time: 00:10:35 UTC
#   Freq: 2.140GHz
#   Calibrator: 3c123
###################################################
def self.createInfoFile(sat, cal) 

  Thread.critical = true;
  if(File.exists?($homeDir + "/" + sat.getOutputFileName() + ".txt"))
    File.delete($homeDir + "/" + sat.getOutputFileName() + ".txt");
  end
  f = File.open($homeDir + "/" + sat.getOutputFileName() + ".txt",  "a")
  f.puts("Satellite:    " + sat.objectName);
  f.puts("NORAD Number: " + sat.norad);
  f.puts("Start:        " + sat.firstPositionTimeDate.sub("T", " ").sub("Z", " ") + " UTC");
  f.puts("End:          " + sat.lastPositionTimeDate.sub("T", " ").sub("Z", " ") + " UTC");
  freq = sat.freqMHz.to_f / 1000.0; #GHz
  f.puts("Freq:         " + freq.to_s + "GHz");
  f.puts("Calibrator:   " + cal.objectName);
  f.flush
  f.fsync
  f.close
  Thread.critical = false;

end

def self.getEmailAddresses(filename)

  arrayFile = File.open(filename, "r")
  returnArray = Array.new#
  while (line = arrayFile.gets)
    line = line.strip
    line = line.rstrip
    if starts_with?(line, "EMAIL:") == true
      parts = line[6..-1].split(";");
      return parts;
    end
  end
  arrayFile.close();

end

def self.getResultsDir(filename)

  arrayFile = File.open(filename, "r")
  returnArray = Array.new#
  while (line = arrayFile.gets)
    line = line.strip
    line = line.rstrip
    if starts_with?(line, "OUTPUT_DIR:") == true
      arrayFile.close();
      return line[11..-1].strip.rstrip;
    end
  end
  arrayFile.close();

  return nil

end

def self.copyResults(sats, outputDir)

  if(outputDir == nil)
    return;
  end

  sats.each do |sat|
    from = $homeDir + "/" + sat.getOutputFileName() + ".pos";
    if(File.exists?(from) == true)
      cmd = "cp " + from + " " + outputDir + "/" + sat.getOutputFileName() + ".pos";
puts cmd;
      system(cmd);
    end
    from = $homeDir + "/" + sat.getOutputFileName() + ".txt";
    if(File.exists?(from) == true)
      to   = outputDir + "/" + sat.getOutputFileName() + ".txt";
      cmd = "cp " + from + " " + outputDir + "/" + sat.getOutputFileName() + ".txt";
puts cmd;
      system(cmd);
     end
    from = $homeDir + "/" + sat.getOutputFileName() + ".obs";
    if(File.exists?(from) == true)
      to   = outputDir + "/" + sat.getOutputFileName() + ".obs";
      cmd = "cp " + from + " " + outputDir + "/" + sat.getOutputFileName() + ".obs";
puts cmd;
      system(cmd);
    end
  end

end

###################################################
# Send an email message on completion
###################################################
def self.sendCompleteEmail(satsOrCals, addresses, outputDir, ellapsedSecs, command)

  report = "";

  addresses.each do |address|

    report = "Processing report for " + $homeDir + " at " + $processingFreqMHz + "MHz" + "\n";

    time = Time.new
    report += "Report created " + time.day.to_s + "/" + time.month.to_s + "/" + time.year.to_s + " " + time.hour.to_s + ":" + time.min.to_s + ":" + time.sec.to_s + "\n\n";

    if(command.eql?("process") || command.eql?("all"))
     satsOrCals.each do |sat|
        if(command.eql?("process") || command.eql?("all"))
          if(sat.posCount > 0)
            report += "\t" + sat.objectName + ", status=" + sat.status + " " + sat.posCount.to_s + " positions calculated\n";
            report += "\t\t" + "Position file:    " + sat.getOutputFileName() + ".pos\n";
            report += "\t\t" + "Description file: " + sat.getOutputFileName() + ".txt\n";
            report += "\t\t" + "AF Position file: " + sat.getOutputFileName() + ".obs\n";
          else
            report += "\t" + sat.objectName + ", status=" + sat.status + "\n";
          end
        end
      end
    end

    if(command.eql?("rfi"))
      satsOrCals.each do |cal|
        report += "\t" + cal.objectName + ", newrfisweep and newcalcal run.\n";
      end
    end


    if(command.eql?("process") || command.eql?("all"))
      report += "\nResults are in #{outputDir}\n";
    end
    report += "\nThe run log is " +  $homeDir + "/log_" + $processingFreqMHz + ".txt\n";
    report += "Processing took #{ellapsedSecs} seconds";
    if(command.eql?("process") || command.eql?("all"))
      report += "\n\n*******************************";
      report += "\n** Standard Deviation Report **";
      report += "\n*******************************";
      report += "\n\n" + std(satsOrCals) + "\n*******************************\n"; 
    end

puts report;

    msg = "Subject: Reduction Report\nFrom: AFReductions\nTo:#{address}\n\n" + report + "\n.\n";

    cmd = "echo \"#{msg}\" | sendmail #{address}";
    `echo \"#{msg}\" | sendmail #{address}`;
  end

    
    # It would be nice to use SMTP, but there is a library conflict that
    # compains about number of arguments. - JR
    #  Net::SMTP.start() do |smtp|
    #    smtp.sendmail( msg,  "", addresses );
    #  end

end

###################################################
# Calc the variance
###################################################

def self.variance(population)
  n = 0
  mean = 0.0
  s = 0.0
  population.each { |x|
    n = n + 1
    delta = x - mean
    mean = mean + (delta / n)
    s = s + delta * (x - mean)
  }
  # if you want to calculate std deviation
  # of a sample change this to "s / (n-1)"
  return s / n
end

###################################################
# Compute the average
###################################################

def self.average(population)
  n = 0
  s = 0.0
  population.each { |x|
    n = n + 1
    s = s + x
  }
  return s / n
end



###################################################
# calculate the standard deviation of a population
# accepts: an array, the population
# returns: the standard deviation
###################################################
def self.std(sats)
  str = "";
  look1 = 0;
  look2 = 0;
  look3 = 0;
  look4 = 0;
  look5 = 0;
  look6 = 0;
  look7 = 0;

  positionThreshold = 8
  looksThreshold = 3
  goodSatArray = Array.new#
  badSatArray = Array.new#
  goodLooks = 0;

  sats.each do |sat|

    lookCount = 0;
    goodLooks = 0;

    posFiles = Dir[$homeDir + "/" + "*#{sat.objectName}*#{sat.freqMHz}*.pos"];
    posFiles.each do |pfn|

      str += "\n\n*************************************************\n";
      str += "Object Name:   " + sat.objectName + "\n";
      str += "Frequency:     " + sat.freqMHz.to_s + " MHz\n";
      str += "Output File:   " +  pfn + "\n";

      posFile = File.open(pfn, "r")

      group = 0;
      values1 = Array.new#
      values2 = Array.new#
      az = Array.new#
      el = Array.new#
      lastTime = "0.0";
      lookTime = "0.0";

      str += "Start Channel: " + sat.startChannel.to_s + "\n";
      str += "End Channel:   " + sat.endChannel.to_s + "\n";
      str += "\n";

      while (line = posFile.gets)
        line = line.strip
        line = line.rstrip

        if(starts_with?(line, "#") == false && starts_with?(line, "T") == false)

          parts = line.chomp.split(" ");
          if(lastTime.eql?("0.0") == true)
            lastTime = parts[0];
          end
          if(lookTime.eql?("0.0") == true)
            lookTime = parts[0];
          end

          if((parts[0].to_f - lastTime.to_f) <= 41.0)
            values1 << parts[5].to_f;
            values2 << parts[6].to_f;
            az << parts[1].to_f;
            el << parts[2].to_f;
          else
            if(values1.length > 1)
              std1 = Math.sqrt(variance(values1));
              std2 = Math.sqrt(variance(values2));
              avg1 = average(values1)*3600.0;
              avg2 = average(values2)*3600.0;
              azAvg = average(az);
              elAvg = average(el);
              values1Count = values1.length;
              values1 = Array.new#
              values2 = Array.new#
              az = Array.new#
              el = Array.new#
              values1 << parts[5].to_f;
              values2 << parts[6].to_f;
              az << parts[1].to_f;
              el << parts[2].to_f;

              firstTimeUTC = UTC2DateTimeString(lookTime);

              #Convert std to arc seconds
              std1  = std1*3600.0;
              std2  = std2*3600.0;

              lookCount = lookCount + 1;

              if(values1Count >= positionThreshold)
                goodLooks = goodLooks + 1;
              end

              group = group + 1;
              str += "[#{group}]\tDate/Time     :\t#{firstTimeUTC.to_s}\n";
              str += "\tTime          :\t#{lookTime.to_s} UTC\n";
              str += "\tPositions     :\t" + values1Count.to_s + "\n";
              str += "\tOffset XEL AVG:\t" + sprintf("%.2f", avg1) + "\tArc Seconds\n";
              str += "\tOffset XEL STD:\t" + sprintf("[%.2f]", std1) + "\tArc Seconds\n";
              str += "\tOffset EL AVG :\t" + sprintf("%.2f", avg2) + "\tArc Seconds\n";
              str += "\tOffset EL STD :\t" + sprintf("[%.2f]", std2) + "\tArc Seconds\n";
              str += "\tAZ MEAN       :\t" + sprintf("%.2f", azAvg) + "\tDegrees\n";
              str += "\tEL MEAN       :\t" + sprintf("%.2f", elAvg) + "\tDegrees\n";
              str += "\n";
              lookTime = "0.0";
            end
          end

          lastTime = parts[0];
        end
      end
      if(values1.length > 1)
        values1Count = values1.length;
        std1 = Math.sqrt(variance(values1));
        std2 = Math.sqrt(variance(values2));
        std1  = std1*3600.0;
        std2  = std2*3600.0;
        avg1 = average(values1)*3600.0;
        avg2 = average(values2)*3600.0;
        azAvg = average(az);
        elAvg = average(el);
        az = Array.new#
        el = Array.new#
        az << parts[1].to_f;
        el << parts[2].to_f;

        lookCount = lookCount + 1;
        if(lookCount == 1) 
          look1 = look1 + 1;
        end
        if(lookCount == 2) 
          look2 = look2 + 1;
        end
        if(lookCount == 3) 
          look3 = look3 + 1;
        end
        if(lookCount == 4) 
          look4 = look4 + 1;
        end
        if(lookCount == 5) 
          look5 = look5 + 1;
        end
        if(lookCount == 6) 
          look6 = look6 + 1;
        end
        if(lookCount == 7) 
          look7 = look7 + 1;
        end
        lookCount = 0;

        firstTimeUTC = UTC2DateTimeString(lookTime);

        if(values1Count >= positionThreshold)
          goodLooks = goodLooks + 1;
        end

        if(goodLooks >= looksThreshold)
          goodSatArray << sat.objectName
        else
          badSatArray << sat.objectName
        end

        group = group + 1;
        str += "[#{group}]\tDate/Time     :\t#{firstTimeUTC.to_s}\n";
        str += "\tTime          :\t#{lookTime.to_s} UTC\n";
        str += "\tPositions     :\t" + values1Count.to_s + "\n";
        str += "\tOffset XEL AVG:\t" + sprintf("%.2f", avg1) + "\tArc Seconds\n";
        str += "\tOffset XEL STD:\t" + sprintf("[%.2f]", std1) + "\tArc Seconds\n";
        str += "\tOffset EL AVG :\t" + sprintf("%.2f", avg2) + "\tArc Seconds\n";
        str += "\tOffset EL STD :\t" + sprintf("[%.2f]", std2) + "\tArc Seconds\n";
        str += "\tAZ MEAN       :\t" + sprintf("%.2f", azAvg) + "\tDegrees\n";
        str += "\tEL MEAN       :\t" + sprintf("%.2f", elAvg) + "\tDegrees\n";
        lookTime = "0.0";
      end
      posFile.close();
    end

  end

  str += "\n\n*** LOOK REPORT ***\n\n";
  if(look1 != 0)
    str += "Sats with 1 look : " + look1.to_s + "\n";
  end
  if(look2 != 0)
    str += "Sats with 2 looks: " + look2.to_s + "\n";
  end
  if(look3 != 0)
    str += "Sats with 3 looks: " + look3.to_s + "\n";
  end
  if(look4 != 0)
    str += "Sats with 4 looks: " + look4.to_s + "\n";
  end
  if(look5 != 0)
    str += "Sats with 5 looks: " + look5.to_s + "\n";
  end
  if(look6 != 0)
    str += "Sats with 6 looks: " + look6.to_s + "\n";
  end
  if(look7 != 0)
    str += "Sats with 7 looks: " + look7.to_s + "\n";
  end

  str += "\n*** Good Sats ***\n\n";
  str += "Satellites with at least " + looksThreshold.to_s + " looks \nwith at least " + positionThreshold.to_s + " positions.\n";
  str += "Count: " + goodSatArray.length.to_s + "\n\n";
  goodSatArray.each do |sat|
    str += sat + "\n";
  end
  str += "\n*** Bad Sats ***\n\n";
  str += "Satellites with less than " + looksThreshold.to_s + " looks \nwith at least " + positionThreshold.to_s + " positions.\n";
  str += "Count: " + badSatArray.length.to_s + "\n\n";
  badSatArray.each do |sat|
    str += sat + "\n";
  end

  str += "\nEND of REPORT";

  return str;
end



###################################################
# Get the usage text.
###################################################
def self.printUsage()
    puts "Usage: <rfi or process or all or quality> freg(MHz)"
end


###################################################
# MAIN
###################################################

  $homeDir = Dir.pwd

  if ARGV.length > 0
    args = ""
    ARGV.each do |arg|
      args += arg + ","
    end
    args = args.chop
  end

  # read args from command line
  if ARGV.length != 2
    puts printUsage();
    exit
  end

  command = ARGV[0];
  $processingFreqMHz = ARGV[1];

  executeAndLog("\n\n****\n\n", false);
  executeAndLog(">>Start Processing \"" + command + "\", " + $homeDir + ", " + $processingFreqMHz + "MHz", false);
  executeAndLog("Source: " + $homeDir, false)

  startSecs = Java::ata::ataTime::ATATime.currentTAINanos/1000000000;

  # Read in the list of cals...
  cals = readArrayFromFile("CAL:", "params_tdrs5.txt", ARGV[1].to_f)
  # Read in the list of sats...
  sats = readArrayFromFile("SAT:", "params_tdrs5.txt", ARGV[1].to_f)

  #report
  executeAndLog(calSatArrayToInfoString("Cals:", cals), false);
  executeAndLog(calSatArrayToInfoString("Sats:", sats), false);

  # execute the operations specified on the command line
  if(command.eql?("rfi") || command.eql?("all"))
    runReduce(cals);
    if(command.eql?("all"))
      processSats(cals, sats);
    end
  else
    if(command.eql?("process"))
      processSats(cals, sats);
    else
      if(command.eql?("quality") == false)
        puts printUsage();
        exit;
      end
    end
  end

  ##Copy results to the output directory
   if(command.eql?("all") || command.eql?("process"))
    outputDir = getResultsDir("params_tdrs5.txt");
    copyResults(sats, outputDir);
   end

  # Send an email report
  emailAddresses = getEmailAddresses("params_tdrs5.txt");
  ellapsedSecs = Java::ata::ataTime::ATATime.currentTAINanos/1000000000 - startSecs;

  if(command.eql?("all") || command.eql?("process"))
    sendCompleteEmail(sats, emailAddresses, outputDir, ellapsedSecs.to_s, command);
  else
    if(command.eql?("rfi"))
      sendCompleteEmail(cals, emailAddresses, outputDir, ellapsedSecs.to_s, command);
    end
    if(command.eql?("quality"))
      puts std(sats);
    end
  end


  executeAndLog(">>Finish Processing \"" + command + "\", " + $homeDir + ", " + $processingFreqMHz + "MHz", false);
